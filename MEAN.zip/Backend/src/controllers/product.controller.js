const ProductModel = require("../models/product.model");
const productValidation = require("../services/validations/product.validation");
const { listProduct } = require("../services/product/product.service");

const {
    SERVERERROR,
    SUCCESS,
    FAILURE,
    ACTIVE_STATUS
} = require("../../config/key");

const responseHelper = require("../helpers/responseHelper");
const productDataTransformer = require("../transformers/user/product.transformer");
const productModel = require("../models/product.model");
const { storeProductImage } = require('../middleware/uploadImage');
const Helper = require("../helpers/Helper");

//signup user
exports.create = async (req, res) => {
    try {

        //store product image using multer middleware
        storeProductImage(req, res, async (err, result) => {
            if (err) {
                return responseHelper.error(res, res.__("" + err), FAILURE);
            } else {

                let reqParam = req.body;

                //server validations
                let validationMessage = await productValidation.createProductValidation(reqParam);
                if (validationMessage) return responseHelper.error(res, res.__(validationMessage), FAILURE);

                var productExist = await ProductModel.findOne({ name: reqParam.name, status: ACTIVE_STATUS });
                if (productExist) return responseHelper.successapi(res, res.__("productExistWithSameName"), SUCCESS);

                //creating request object
                let newProduct = productModel({
                    name: reqParam.name,
                    description: reqParam.description,
                    price: reqParam.price,
                    image: req.file && req.file !== undefined ? req.file.filename : '',
                    status: ACTIVE_STATUS
                })

                //save product
                const response = await newProduct.save();

                //response data manipulation 
                const responseData = await productDataTransformer.transform(response);

                return responseHelper.successapi(res, res.__("productCreated"), SUCCESS, responseData);
            }
        });
    } catch (e) {
        console.log(e)
        return responseHelper.error(res, res.__("SomethingWentWrongPleaseTryAgain"), SERVERERROR);
    }
};


//list project
exports.list = async (req, res) => {
    try {
        const { limitCount, skipCount } = Helper.getPageAndLimit(req.body.page, req.body.limit);

        let reqParam = req.body;

        const productList = await listProduct({
            skip: skipCount,
            limit: limitCount,
            name: reqParam.name
        });

        //response data 
        let response = productList && productList.length > 0 ? productList[0].data : [];
        
        //response data manipulation 
        const responseData = await productDataTransformer.transformListCollection(response);

        return responseHelper.successapi(res, res.__("ProductList"), SUCCESS, responseData);

    } catch (e) {
        console.log(e)
        return responseHelper.error(res, res.__("SomethingWentWrongPleaseTryAgain"), SERVERERROR);
    }
};