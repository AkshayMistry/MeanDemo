const multer = require("multer");
const path = require("path");
const fs = require("fs-extra");

//Upload Product Image
const productImagePath = path.join(__dirname, "../../public/images/products");

const productImagesStorage = multer.diskStorage({
	destination: function (req, file, cb) {
		if (!fs.existsSync(productImagePath)) {
			fs.mkdirSync(productImagePath, { recursive: true }, (err) => {});
		}
		cb(null, productImagePath);
	},
	filename: function (req, file, cb) {
		cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname));
	},
});
exports.storeProductImage = multer({
	storage: productImagesStorage,
	limits: {
		fileSize: 1024 * 1024 * 1024,
	},
	fileFilter(req, file, cb) {
		if (!file.originalname.match(/\.(jpg|JPG|jpeg|JPEG|png|PNG|gif)$/)) {
			return cb(new Error("Please upload an image!"), false);
		}
		cb(undefined, true);
	},
}).single("image");

exports.productImageURL = (filename) => {
	return `${APP_URL}/images/products/${filename}`;
};


