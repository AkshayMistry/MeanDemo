require("./connections/db");
require("dotenv").config();

const express = require("express");
var bodyparser = require("body-parser");
const i18n = require("./i18n/i18n");
const http = require("http");
const cors = require("cors");
const app = express();
const { PORT } = require("../config/key");
const server = http.createServer(app);
const path = require("path");
app.use(bodyparser.json({ limit: "500mb" }));

// cors
app.use(cors());
app.options("*", cors());

// public path
const publicDirectory = path.join(__dirname, "../public");
app.use(express.static(publicDirectory));

// language file
app.use(i18n);

// server
server.listen(PORT, () => {
	console.log("server listening on port : ", PORT);
});

// routing
app.get("/", (req, res) => {
	res.send("Testing from the node.");
});

const product = require("./routes/product.route");
app.use("/api/v1/product", product);
