const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
	{
		name: {
			type: String,
			required: true,
		},
		description: {
			type: String,
			required: true,
		},
		price: {
			type: Number,
			required: true
		},
		image: {
			type: String,
		},
        status: {
			type: Number,
			default: 1,
			enum: [1, 2, 3],    //1=Active 2=InActive 3=Deleted
		},
	},
	{ collection: "products", timestamps: true },
);
module.exports = mongoose.model("products", productSchema);
