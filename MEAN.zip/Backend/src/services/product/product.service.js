const ProductModel = require("../../models/product.model");
const { facetHelper } = require("../../helpers/pagination.helper");
var ObjectId = require("mongodb").ObjectId;
const {
    ACTIVE_STATUS
} = require("../../../config/key");

//list notification
exports.listProduct = async (data) => {
    try {
        let pipeline = [];

        //adding query into the pipeline array
        pipeline.push({
            $match: {
                name : {
                    $regex : data.name
                },
                status: ACTIVE_STATUS,
            },
        });

        //projection
		let projection = {
			name: 1,
			description: 1,
			price : 1,
			image: 1,
			status: 1
		}

        pipeline.push({ 
            $sort: { 
                createdAt: -1 
            } 
        }, { 
            $project: projection 
        }, facetHelper(Number(data.skip), Number(data.limit)));

        //query execute
        const result = await ProductModel.aggregate(pipeline);
		return result;

    } catch (e) {
        console.log(e);
        return false;
    }
}