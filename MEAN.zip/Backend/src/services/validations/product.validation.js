// eslint-disable-next-line import/no-extraneous-dependencies
const Joi = require("joi");
const helper = require("../../helpers/helper");

module.exports = {
	async createProductValidation(req) {
		const schema = Joi.object({
			name: Joi.string().required(),
			description: Joi.string().required(),
			price: Joi.string().required().regex(/^\d+$/)
		}).unknown(true);
		const { error } = schema.validate(req);
		if (error) {
            console.log("error"+error)
			return helper.validationMessageKey("validation", error);
		}
		return null;
	}
};
