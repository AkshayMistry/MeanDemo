const Helper = require("../../helpers/helper");

exports.transform = (data) => {
	return {
		_id: data._id,
		name: data.name,
		description: data.description,
		price: data.price,
		image: data.image ? Helper.productImageUrl(data.image) : Helper.defaultProductImageURL(),
		status : data.status == 1 ? 'Active' : 'Inactive',
        createdAt: data.createdAt,
	};
};

exports.transformListCollection = (arrayData) => {
	let data = [];
	if (arrayData && arrayData.length > 0) {
		arrayData.forEach((a) => {
			data.push(this.transform(a));   
		});
	}
	arrayData = data;
	return arrayData;
};
 