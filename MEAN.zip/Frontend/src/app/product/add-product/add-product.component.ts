import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../services/product.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
})
export class AddProductComponent implements OnInit {

  public addProductObj: any = {};

  constructor(public productService: ProductService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit(): void {
  }

  back(){
    this.router.navigate([''])
  }
  
  /**
	* Event of submit button.
    * @param isValid Form validation status.
	*/
  onSubmit() {
    this.addProductObj;
    this.productService.productAdd(this.addProductObj).subscribe((response  : any) => {
      this.router.navigate([''])
    })
  }
}
