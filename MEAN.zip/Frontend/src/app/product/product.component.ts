import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html'
})


export class ProductComponent implements OnInit {

  public productList : any;
  public searchString : any;

  constructor(public productService: ProductService, private router: Router) { }

  public bodyParam = {
    name : '',
    page : 1,
    limit : 10
  } 

  ngOnInit(): void {
    this.fetchProduct();
  }

  fetchProduct(){
    this.productService.productList(this.bodyParam).subscribe((response  : any) => {
      this.productList = response.data;
    })
  }

  onKeyUp(x:any) { // appending the updated value to the variable
    this.bodyParam.name = x.target.value;
    this.fetchProduct();
  }

  redirect(){
    this.router.navigate(['product/add'])
  }
}
