import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  API_URL = `${environment.apiUrl}product/`;
  constructor(private http: HttpClient) { }

  // public methods
  productList(bodyParam:any) {
    return this.http.post(this.API_URL + 'list', bodyParam,{})
  }
 
  productAdd(bodyParam:any) {
    return this.http.post(this.API_URL + 'create', bodyParam,{})
  }
}
